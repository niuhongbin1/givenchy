def ded(du):
    dus = du.split('/N-')



    return dus[-1]



